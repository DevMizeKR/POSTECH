/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_304(unsigned x)
{
    return x + 2420671246U;
}

void setval_371(unsigned *p)
{
    *p = 2425376970U;
}

unsigned addval_101(unsigned x)
{
    return x + 3284633928U;
}

unsigned getval_422()
{
    return 2879963992U;
}

unsigned addval_262(unsigned x)
{
    return x + 3347662993U;
}

unsigned getval_190()
{
    return 3251079496U;
}

unsigned getval_237()
{
    return 3277327910U;
}

void setval_311(unsigned *p)
{
    *p = 3284633929U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_257(unsigned x)
{
    return x + 3525362056U;
}

unsigned addval_243(unsigned x)
{
    return x + 3531921033U;
}

unsigned addval_310(unsigned x)
{
    return x + 3232028297U;
}

unsigned addval_309(unsigned x)
{
    return x + 2425673353U;
}

unsigned addval_363(unsigned x)
{
    return x + 3389644134U;
}

unsigned addval_344(unsigned x)
{
    return x + 3264266633U;
}

void setval_152(unsigned *p)
{
    *p = 3281043913U;
}

void setval_238(unsigned *p)
{
    *p = 2447411528U;
}

unsigned getval_138()
{
    return 3286272328U;
}

void setval_294(unsigned *p)
{
    *p = 3534012809U;
}

unsigned getval_450()
{
    return 3286280520U;
}

void setval_449(unsigned *p)
{
    *p = 3224426121U;
}

unsigned getval_218()
{
    return 3599329729U;
}

unsigned getval_255()
{
    return 3221801481U;
}

unsigned getval_494()
{
    return 3222850185U;
}

unsigned addval_204(unsigned x)
{
    return x + 3221804713U;
}

void setval_439(unsigned *p)
{
    *p = 3766569007U;
}

unsigned getval_480()
{
    return 3229925769U;
}

unsigned getval_192()
{
    return 3677932169U;
}

unsigned getval_103()
{
    return 3286272328U;
}

void setval_276(unsigned *p)
{
    *p = 3281174921U;
}

unsigned getval_493()
{
    return 3398028374U;
}

unsigned getval_249()
{
    return 3399051893U;
}

unsigned getval_239()
{
    return 3229928075U;
}

void setval_407(unsigned *p)
{
    *p = 2430634248U;
}

void setval_393(unsigned *p)
{
    *p = 3286288712U;
}

void setval_200(unsigned *p)
{
    *p = 3525362057U;
}

unsigned getval_154()
{
    return 3222853257U;
}

unsigned addval_329(unsigned x)
{
    return x + 3264266633U;
}

unsigned getval_332()
{
    return 3677407881U;
}

unsigned addval_133(unsigned x)
{
    return x + 3286272072U;
}

void setval_303(unsigned *p)
{
    *p = 3532969609U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
